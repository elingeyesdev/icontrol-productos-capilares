<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{

    public function up(): void
    {
        DB::statement("ALTER TABLE compras MODIFY estado ENUM('completada','cancelada','eliminada') NOT NULL DEFAULT 'completada'");
        DB::statement("ALTER TABLE ventas MODIFY estado ENUM('completada','cancelada','eliminada') NOT NULL DEFAULT 'completada'");
        DB::statement("ALTER TABLE pedidos MODIFY estado ENUM('pendiente','confirmado','entregado','cancelado','eliminado') NOT NULL DEFAULT 'pendiente'");
    }

    public function down(): void
    {
        DB::statement("UPDATE compras SET estado = 'cancelada' WHERE estado = 'eliminada'");
        DB::statement("UPDATE ventas SET estado = 'cancelada' WHERE estado = 'eliminada'");
        DB::statement("UPDATE pedidos SET estado = 'cancelado' WHERE estado = 'eliminado'");

        DB::statement("ALTER TABLE compras MODIFY estado ENUM('completada','cancelada') NOT NULL DEFAULT 'completada'");
        DB::statement("ALTER TABLE ventas MODIFY estado ENUM('completada','cancelada') NOT NULL DEFAULT 'completada'");
        DB::statement("ALTER TABLE pedidos MODIFY estado ENUM('pendiente','confirmado','entregado','cancelado') NOT NULL DEFAULT 'pendiente'");
    }
};
