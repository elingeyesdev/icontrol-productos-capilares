<x-app-layout>
    <div>
        <x-reportes.banner titulo="Reporte de compras" subtitulo="{{ $compras->count() }} compra{{ $compras->count() !== 1 ? 's' : '' }} completada{{ $compras->count() !== 1 ? 's' : '' }} en el rango seleccionado" />

        <a href="{{ route('reportes.index') }}" style="display:inline-flex; align-items:center; gap:6px; margin-bottom:14px; font-size:13px; font-weight:700; color:var(--clr-accent); text-decoration:none;">
            <i class="bi bi-arrow-left"></i> Volver a reportes
        </a>

        <div class="usr-toolbar mb-4">
            <form method="GET" style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
                <input type="date" name="desde" value="{{ $desde->format('Y-m-d') }}" class="filter-input" style="max-width:160px;">
                <span style="font-size:12.5px; color:var(--clr-sub);">hasta</span>
                <input type="date" name="hasta" value="{{ $hasta->format('Y-m-d') }}" class="filter-input" style="max-width:160px;">
                <select name="id_proveedor" class="filter-select" style="max-width:200px;">
                    <option value="">Todos los proveedores</option>
                    @foreach($proveedores as $p)
                        <option value="{{ $p->id }}" {{ request('id_proveedor') == $p->id ? 'selected' : '' }}>{{ $p->nombre_empresa }}</option>
                    @endforeach
                </select>
                <button type="submit" class="btn-add-user"><i class="bi bi-funnel-fill"></i> Filtrar</button>
            </form>
            <a href="{{ route('reportes.compras.pdf', request()->query()) }}" target="_blank" rel="noopener" class="btn-add-user">
                <i class="bi bi-file-earmark-pdf-fill"></i> Vista previa PDF
            </a>
        </div>

        <div class="usr-table-card">
            @if($compras->isEmpty())
                <p class="mensaje-vacio"><i class="bi bi-inbox"></i> No hay compras en este rango.</p>
            @else
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Proveedor</th>
                            <th>Registrado por</th>
                            <th>Total</th>
                            <th>Fecha</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($compras as $compra)
                            <tr>
                                <td>#{{ $compra->id }}</td>
                                <td style="font-weight:700;">{{ $compra->proveedor->nombre_empresa ?? '—' }}</td>
                                <td>{{ $compra->usuario->name ?? '—' }}</td>
                                <td>Bs. {{ number_format($compra->total, 2) }}</td>
                                <td>{{ $compra->fecha->format('d/m/Y H:i') }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" style="text-align:right; font-weight:800;">Total</td>
                            <td colspan="2" style="font-weight:800; color:var(--clr-accent);">Bs. {{ number_format($totalCompras, 2) }}</td>
                        </tr>
                    </tfoot>
                </table>
            @endif
        </div>
    </div>
</x-app-layout>
