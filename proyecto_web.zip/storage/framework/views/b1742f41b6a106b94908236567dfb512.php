<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['centered' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
    <h1>Crea tu cuenta</h1>
    <p class="login-subtitle">Únete a Luciane</p>
    <hr class="form-divider">

    <?php if($errors->any()): ?>
        <div class="alert alert-error">
            <i class="bi bi-exclamation-triangle-fill"></i>
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="name">Nombre completo</label>
            <input id="name" type="text" name="name" value="<?php echo e(old('name')); ?>"
                   placeholder="Tu nombre" required autofocus autocomplete="name">
        </div>

        <div class="form-group">
            <label for="email">Correo electrónico</label>
            <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>"
                   placeholder="tucorreo@ejemplo.com" required autocomplete="username">
        </div>

        <div class="form-group" x-data="{ show: false }">
            <label for="password">Contraseña</label>
            <div class="password-container">
                <input :type="show ? 'text' : 'password'" id="password" name="password"
                       placeholder="••••••••" required autocomplete="new-password">
                <button type="button" class="password-toggle" @click="show = !show">
                    <i class="bi" :class="show ? 'bi-eye-slash' : 'bi-eye'"></i>
                </button>
            </div>
            <small>Mínimo 8 caracteres</small>
        </div>

        <div class="form-group" x-data="{ show: false }">
            <label for="password_confirmation">Confirmar contraseña</label>
            <div class="password-container">
                <input :type="show ? 'text' : 'password'" id="password_confirmation" name="password_confirmation"
                       placeholder="••••••••" required autocomplete="new-password">
                <button type="button" class="password-toggle" @click="show = !show">
                    <i class="bi" :class="show ? 'bi-eye-slash' : 'bi-eye'"></i>
                </button>
            </div>
        </div>

        <button type="submit" class="btn-login">Crear cuenta</button>
    </form>

    <p class="register-link">
        ¿Ya tienes cuenta? <a href="<?php echo e(route('login')); ?>">Inicia sesión</a>
    </p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\control-productos-capilares\resources\views/auth/register.blade.php ENDPATH**/ ?>