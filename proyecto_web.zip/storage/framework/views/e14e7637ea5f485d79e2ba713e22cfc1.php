<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $usuariosSinRol = $usuarios->filter(fn ($u) => $u->roles->isEmpty()); ?>
    <div x-data="{ assignRol: null, deleteRol: null }">

        <div class="section-header">
            <div>
                <h1 class="text-3xl mb-1">Administrar Rol Usuario</h1>
                <p><?php echo e($usuarios->count()); ?> usuario<?php echo e($usuarios->count() !== 1 ? 's' : ''); ?> registrado<?php echo e($usuarios->count() !== 1 ? 's' : ''); ?></p>
            </div>
        </div>

        <?php if(session('status')): ?>
            <div class="alert alert-success mb-4"><i class="bi bi-check-circle-fill"></i> <?php echo e(session('status')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-error mb-4"><i class="bi bi-exclamation-triangle-fill"></i> <?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <div class="usr-toolbar mb-4">
            <form method="GET" style="display:flex; flex-direction:column; gap:8px;">
                <div style="display:flex; gap:8px; flex-wrap:wrap;">
                    <div class="nav-search" style="position:relative; max-width:300px;">
                        <i class="bi bi-search search-icon"></i>
                        <input type="text" name="buscar" value="<?php echo e(request('buscar')); ?>" placeholder="Buscar por nombre o correo…">
                    </div>
                    <button type="submit" class="btn-add-user"><i class="bi bi-search"></i> Buscar</button>
                </div>
                <?php if (isset($component)) { $__componentOriginal6490a6a53964ee40004ce690923a963a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6490a6a53964ee40004ce690923a963a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort-select','data' => ['sort' => $sort,'dir' => $dir,'options' => [
                    'id|desc' => 'Más recientes primero',
                    'id|asc' => 'Más antiguos primero',
                    'name|asc' => 'Nombre (A-Z)',
                    'name|desc' => 'Nombre (Z-A)',
                    'email|asc' => 'Correo (A-Z)',
                ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                    'id|desc' => 'Más recientes primero',
                    'id|asc' => 'Más antiguos primero',
                    'name|asc' => 'Nombre (A-Z)',
                    'name|desc' => 'Nombre (Z-A)',
                    'email|asc' => 'Correo (A-Z)',
                ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6490a6a53964ee40004ce690923a963a)): ?>
<?php $attributes = $__attributesOriginal6490a6a53964ee40004ce690923a963a; ?>
<?php unset($__attributesOriginal6490a6a53964ee40004ce690923a963a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6490a6a53964ee40004ce690923a963a)): ?>
<?php $component = $__componentOriginal6490a6a53964ee40004ce690923a963a; ?>
<?php unset($__componentOriginal6490a6a53964ee40004ce690923a963a); ?>
<?php endif; ?>
            </form>
            <button type="button" class="btn-add-user"
                    @click="assignRol = { esNuevo: true, user_id: '<?php echo e($usuariosSinRol->first()->id ?? ''); ?>', nombre: '', role: '' }">
                <i class="bi bi-person-fill-add"></i> Añadir
            </button>
        </div>

        <div class="usr-table-card">
            <?php if($usuarios->isEmpty()): ?>
                <p class="mensaje-vacio"><i class="bi bi-people"></i> No hay usuarios registrados.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Usuario</th>
                            <th>Correo</th>
                            <th>Rol actual</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $rolActual = $usuario->roles->first()?->name;
                                $rolClass = match($rolActual) {
                                    'administrador' => 'rol-admin',
                                    'cliente' => 'rol-cliente',
                                    'vendedor' => 'rol-delivery',
                                    default => 'rol-default',
                                };
                            ?>
                            <tr>
                                <td style="font-weight:700;"><?php echo e($usuario->name); ?></td>
                                <td><?php echo e($usuario->email); ?></td>
                                <td>
                                    <span class="rol-badge <?php echo e($rolClass); ?>"><?php echo e($rolActual ? ucfirst($rolActual) : 'Sin rol'); ?></span>
                                </td>
                                <td>
                                    <div style="display:flex; gap:6px; justify-content:center;">
                                        <button type="button" class="btn-editar" title="Editar rol"
                                                @click="assignRol = {
                                                    esNuevo: false,
                                                    user_id: <?php echo e($usuario->id); ?>,
                                                    nombre: '<?php echo e(addslashes($usuario->name)); ?>',
                                                    role: '<?php echo e($rolActual); ?>',
                                                    rolClass: '<?php echo e($rolClass); ?>'
                                                }">
                                            <i class="bi bi-pencil-fill"></i>
                                        </button>
                                        <?php if($rolActual): ?>
                                            <button type="button" class="btn-eliminar" title="Eliminar rol"
                                                    @click="deleteRol = { id: <?php echo e($usuario->id); ?>, nombre: '<?php echo e(addslashes($usuario->name)); ?>', role: '<?php echo e($rolActual); ?>' }">
                                                <i class="bi bi-trash-fill"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <div x-show="assignRol" x-cloak class="fixed inset-0 z-[1300] flex items-center justify-center p-4"
             style="background: rgba(50,20,70,.45); backdrop-filter: blur(6px);">
            <div @click.outside="assignRol = null" class="usr-modal-box usr-modal-box--md">
                <button type="button" class="usr-modal-close" @click="assignRol = null"><i class="bi bi-x-lg"></i></button>
                <template x-if="assignRol">
                    <div>
                        <div class="usr-modal-header">
                            <span class="usr-modal-icon" style="background:var(--purple-bg); color:var(--clr-accent);">
                                <i class="bi bi-person-badge"></i>
                            </span>
                            <h2 class="usr-modal-title" x-text="assignRol.esNuevo ? 'Asignar rol' : 'Cambiar rol'"></h2>
                        </div>
                        <div class="usr-modal-body">
                            <form method="POST" action="<?php echo e(route('usuario-roles.store')); ?>" class="usr-card-main">
                                <?php echo csrf_field(); ?>

                                <template x-if="assignRol.esNuevo">
                                    <div>
                                        <label>Usuario</label>
                                        <select name="user_id" x-model="assignRol.user_id" required>
                                            <?php $__empty_1 = true; $__currentLoopData = $usuariosSinRol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($usuario->id); ?>"><?php echo e($usuario->name); ?> — <?php echo e($usuario->email); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <option value="" disabled>No hay usuarios sin rol</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </template>

                                <template x-if="!assignRol.esNuevo">
                                    <div>
                                        <label>Usuario</label>
                                        <input type="text" :value="assignRol.nombre" readonly disabled>
                                        <input type="hidden" name="user_id" :value="assignRol.user_id">
                                    </div>
                                </template>

                                <p class="usr-section-label">Rol</p>
                                <div class="usr-role-pills">
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $pillClass = match($r->name) {
                                                'administrador' => 'rol-admin',
                                                'cliente' => 'rol-cliente',
                                                'vendedor' => 'rol-delivery',
                                                default => 'rol-default',
                                            };
                                        ?>
                                        <button type="button" class="usr-role-pill"
                                                :class="assignRol.role === '<?php echo e($r->name); ?>' ? 'active' : ''"
                                                @click="assignRol.role = '<?php echo e($r->name); ?>'; assignRol.rolClass = '<?php echo e($pillClass); ?>';">
                                            <?php echo e(ucfirst($r->name)); ?>

                                        </button>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <input type="hidden" name="role" x-model="assignRol.role">

                                <div class="usr-modal-footer">
                                    <button type="button" class="usr-btn-cancel" @click="assignRol = null">Cancelar</button>
                                    <button type="submit" class="usr-btn-submit"><i class="bi bi-check-lg"></i> Guardar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </template>
            </div>
        </div>

        <div x-show="deleteRol" x-cloak class="fixed inset-0 z-[1300] flex items-center justify-center p-4"
             style="background: rgba(50,20,70,.45); backdrop-filter: blur(6px);">
            <div @click.outside="deleteRol = null" class="usr-modal-box usr-modal-box--sm">
                <button type="button" class="usr-modal-close" @click="deleteRol = null"><i class="bi bi-x-lg"></i></button>
                <div class="usr-modal-header">
                    <span class="usr-modal-icon" style="background:#fde8e8; color:#b03030;">
                        <i class="bi bi-trash3-fill"></i>
                    </span>
                    <h2 class="usr-modal-title" style="color:#b03030;">Eliminar rol</h2>
                </div>
                <template x-if="deleteRol">
                    <div class="usr-modal-body">
                        <p class="usr-delete-msg">
                            ¿Seguro que deseas quitarle el rol <strong x-text="deleteRol.role"></strong> a <strong x-text="deleteRol.nombre"></strong>?
                            El usuario quedará sin rol asignado.
                        </p>
                        <form :action="deleteRol ? '<?php echo e(url('rol-usuario')); ?>/' + deleteRol.id : ''" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <div class="usr-modal-footer">
                                <button type="button" class="usr-btn-cancel" @click="deleteRol = null">Cancelar</button>
                                <button type="submit" class="usr-btn-delete"><i class="bi bi-trash3"></i> Eliminar</button>
                            </div>
                        </form>
                    </div>
                </template>
            </div>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\control-productos-capilares\resources\views/usuario-roles/index.blade.php ENDPATH**/ ?>