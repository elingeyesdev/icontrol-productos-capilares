<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['options', 'sort' => null, 'dir' => 'desc']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['options', 'sort' => null, 'dir' => 'desc']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $current = ($sort ?? array_key_first($options)) . '|' . $dir;
?>

<div class="usr-sort-select">
    <i class="bi bi-sort-down-alt"></i>
    <select aria-label="Ordenar por" onchange="
        const [f, d] = this.value.split('|');
        const form = this.closest('form');
        form.querySelector('[data-sort-field]').value = f;
        form.querySelector('[data-sort-dir]').value = d;
        form.submit();
    ">
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php if($value === $current): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <input type="hidden" name="sort" value="<?php echo e($sort); ?>" data-sort-field>
    <input type="hidden" name="dir" value="<?php echo e($dir); ?>" data-sort-dir>
</div>
<?php /**PATH C:\laragon\www\control-productos-capilares\resources\views/components/sort-select.blade.php ENDPATH**/ ?>