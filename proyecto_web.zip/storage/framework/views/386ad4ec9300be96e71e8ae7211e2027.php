<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['centered' => true]); ?>
    <h1>Bienvenid@ de nuevo</h1>
    <p class="login-subtitle">Inicia sesión para continuar</p>
    <hr class="form-divider">

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <i class="bi bi-check-circle-fill"></i> <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-error">
            <i class="bi bi-exclamation-triangle-fill"></i>
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="email">Correo electrónico</label>
            <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>"
                   placeholder="tucorreo@ejemplo.com" required autofocus autocomplete="username">
        </div>

        <div class="form-group" x-data="{ show: false }">
            <label for="password">Contraseña</label>
            <div class="password-container">
                <input :type="show ? 'text' : 'password'" id="password" name="password"
                       placeholder="••••••••" required autocomplete="current-password">
                <button type="button" class="password-toggle" @click="show = !show">
                    <i class="bi" :class="show ? 'bi-eye-slash' : 'bi-eye'"></i>
                </button>
            </div>
        </div>

        <div class="form-group" style="display:flex; align-items:center; justify-content:space-between;">
            <label style="display:flex; align-items:center; gap:6px; margin-bottom:0; font-weight:400;">
                <input type="checkbox" name="remember" style="width:auto;">
                Recordarme
            </label>

            <?php if(Route::has('password.request')): ?>
                <a href="<?php echo e(route('password.request')); ?>" style="font-size:12px; color:#e8c6e8;">
                    ¿Olvidaste tu contraseña?
                </a>
            <?php endif; ?>
        </div>

        <button type="submit" class="btn-login">Iniciar sesión</button>
    </form>

    <p class="register-link">
        ¿No tienes cuenta? <a href="<?php echo e(route('register')); ?>">Regístrate aquí</a>
    </p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\control-productos-capilares\resources\views/auth/login.blade.php ENDPATH**/ ?>