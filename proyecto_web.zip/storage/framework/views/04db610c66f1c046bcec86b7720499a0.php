<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div x-data="{ showCreate: false, editProv: null, deleteProv: null }">

        <div class="section-header">
            <div>
                <h1 class="text-3xl mb-1">Administrar Proveedores</h1>
                <p><?php echo e($proveedores->count()); ?> proveedor<?php echo e($proveedores->count() !== 1 ? 'es' : ''); ?> registrado<?php echo e($proveedores->count() !== 1 ? 's' : ''); ?></p>
            </div>
        </div>

        <?php if(session('status')): ?>
            <div class="alert alert-success mb-4">
                <i class="bi bi-check-circle-fill"></i> <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-error mb-4">
                <i class="bi bi-exclamation-triangle-fill"></i> <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <div class="usr-toolbar mb-4">
            <form method="GET" style="display:flex; flex-direction:column; gap:8px;">
                <div style="display:flex; gap:8px; flex-wrap:wrap;">
                    <div class="nav-search" style="position:relative; max-width:340px;">
                        <i class="bi bi-search search-icon"></i>
                        <input type="text" name="buscar" value="<?php echo e(request('buscar')); ?>" placeholder="Buscar proveedor…">
                    </div>
                    <button type="submit" class="btn-add-user"><i class="bi bi-search"></i> Buscar</button>
                </div>
                <?php if (isset($component)) { $__componentOriginal6490a6a53964ee40004ce690923a963a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6490a6a53964ee40004ce690923a963a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort-select','data' => ['sort' => $sort,'dir' => $dir,'options' => [
                    'id|desc' => 'Más recientes primero',
                    'id|asc' => 'Más antiguos primero',
                    'nombre|asc' => 'Nombre (A-Z)',
                    'nombre|desc' => 'Nombre (Z-A)',
                    'compras|desc' => 'Más compras primero',
                    'activo|desc' => 'Estado',
                ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                    'id|desc' => 'Más recientes primero',
                    'id|asc' => 'Más antiguos primero',
                    'nombre|asc' => 'Nombre (A-Z)',
                    'nombre|desc' => 'Nombre (Z-A)',
                    'compras|desc' => 'Más compras primero',
                    'activo|desc' => 'Estado',
                ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6490a6a53964ee40004ce690923a963a)): ?>
<?php $attributes = $__attributesOriginal6490a6a53964ee40004ce690923a963a; ?>
<?php unset($__attributesOriginal6490a6a53964ee40004ce690923a963a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6490a6a53964ee40004ce690923a963a)): ?>
<?php $component = $__componentOriginal6490a6a53964ee40004ce690923a963a; ?>
<?php unset($__componentOriginal6490a6a53964ee40004ce690923a963a); ?>
<?php endif; ?>
            </form>
            <button type="button" class="btn-add-user" @click="showCreate = true">
                <i class="bi bi-truck"></i> Nuevo Proveedor
            </button>
        </div>

        <div class="usr-table-card">
            <?php if($proveedores->isEmpty()): ?>
                <p class="mensaje-vacio"><i class="bi bi-truck"></i> No hay proveedores registrados.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th style="text-align:center;">ID</th>
                            <th>Empresa</th>
                            <th>Contacto</th>
                            <th>Teléfono</th>
                            <th>Email</th>
                            <th style="text-align:center;">Compras</th>
                            <th style="text-align:center;">Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong>#<?php echo e($prov->id); ?></strong></td>
                                <td style="font-weight:700;"><?php echo e($prov->nombre_empresa); ?></td>
                                <td><?php echo e($prov->contacto ?: '—'); ?></td>
                                <td><?php echo e($prov->telefono ?: '—'); ?></td>
                                <td><?php echo e($prov->email ?: '—'); ?></td>
                                <td>
                                    <span class="rol-badge" style="background:var(--purple-bg);color:#5a30a0;">
                                        <?php echo e($prov->compras_count); ?>

                                    </span>
                                </td>
                                <td>
                                    <?php if($prov->activo): ?>
                                        <span class="estado-activo"><i class="bi bi-circle-fill" style="font-size:7px"></i> Activo</span>
                                    <?php else: ?>
                                        <span class="estado-inactivo"><i class="bi bi-circle-fill" style="font-size:7px"></i> Inactivo</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div style="display:flex; gap:6px; justify-content:center;">
                                        <button type="button" class="btn-editar"
                                                @click="editProv = {
                                                    id: <?php echo e($prov->id); ?>,
                                                    nombre_empresa: '<?php echo e(addslashes($prov->nombre_empresa)); ?>',
                                                    contacto: '<?php echo e(addslashes($prov->contacto ?? '')); ?>',
                                                    telefono: '<?php echo e(addslashes($prov->telefono ?? '')); ?>',
                                                    email: '<?php echo e(addslashes($prov->email ?? '')); ?>',
                                                    direccion: '<?php echo e(addslashes($prov->direccion ?? '')); ?>',
                                                    activo: <?php echo e($prov->activo ? 'true' : 'false'); ?>

                                                }">
                                            <i class="bi bi-pencil-fill"></i>
                                        </button>
                                        <button type="button" class="btn-eliminar"
                                                @click="deleteProv = { id: <?php echo e($prov->id); ?>, nombre: '<?php echo e(addslashes($prov->nombre_empresa)); ?>' }">
                                            <i class="bi bi-trash-fill"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <div x-show="showCreate" x-cloak class="fixed inset-0 z-[1300] flex items-center justify-center p-4"
             style="background: rgba(50,20,70,.45); backdrop-filter: blur(6px);">
            <div @click.outside="showCreate = false" class="usr-modal-box usr-modal-box--sm">
                <button type="button" class="usr-modal-close" @click="showCreate = false"><i class="bi bi-x-lg"></i></button>
                <div class="usr-modal-header">
                    <span class="usr-modal-icon" style="background:var(--mint-bg); color:#2a7a5a;"><i class="bi bi-truck"></i></span>
                    <h2 class="usr-modal-title">Nuevo <span>proveedor</span></h2>
                </div>
                <div class="usr-modal-body">
                    <form method="POST" action="<?php echo e(route('proveedores.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group" style="margin-bottom:14px;">
                            <label style="color:var(--clr-text); font-size:12px; font-weight:700; display:block; margin-bottom:5px;">Nombre de la empresa</label>
                            <input type="text" name="nombre_empresa" required maxlength="150"
                                   style="width:100%; padding:9px 13px; border:1.5px solid rgba(180,138,212,.4); border-radius:10px; font-size:13px; background:#fff; color:var(--clr-text);">
                        </div>
                        <div class="form-group" style="margin-bottom:14px;">
                            <label style="color:var(--clr-text); font-size:12px; font-weight:700; display:block; margin-bottom:5px;">Persona de contacto</label>
                            <input type="text" name="contacto" maxlength="150"
                                   style="width:100%; padding:9px 13px; border:1.5px solid rgba(180,138,212,.4); border-radius:10px; font-size:13px; background:#fff; color:var(--clr-text);">
                        </div>
                        <div class="form-group" style="margin-bottom:14px;">
                            <label style="color:var(--clr-text); font-size:12px; font-weight:700; display:block; margin-bottom:5px;">Teléfono</label>
                            <input type="text" name="telefono" maxlength="20"
                                   style="width:100%; padding:9px 13px; border:1.5px solid rgba(180,138,212,.4); border-radius:10px; font-size:13px; background:#fff; color:var(--clr-text);">
                        </div>
                        <div class="form-group" style="margin-bottom:14px;">
                            <label style="color:var(--clr-text); font-size:12px; font-weight:700; display:block; margin-bottom:5px;">Email</label>
                            <input type="email" name="email" maxlength="255"
                                   style="width:100%; padding:9px 13px; border:1.5px solid rgba(180,138,212,.4); border-radius:10px; font-size:13px; background:#fff; color:var(--clr-text);">
                        </div>
                        <div class="form-group" style="margin-bottom:14px;">
                            <label style="color:var(--clr-text); font-size:12px; font-weight:700; display:block; margin-bottom:5px;">Dirección</label>
                            <input type="text" name="direccion" maxlength="255"
                                   style="width:100%; padding:9px 13px; border:1.5px solid rgba(180,138,212,.4); border-radius:10px; font-size:13px; background:#fff; color:var(--clr-text);">
                        </div>
                        <div class="usr-modal-footer">
                            <button type="button" class="usr-btn-cancel" @click="showCreate = false">Cancelar</button>
                            <button type="submit" class="usr-btn-submit"><i class="bi bi-check-lg"></i> Crear</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div x-show="editProv" x-cloak class="fixed inset-0 z-[1300] flex items-center justify-center p-4"
             style="background: rgba(50,20,70,.45); backdrop-filter: blur(6px);">
            <div @click.outside="editProv = null" class="usr-modal-box usr-modal-box--sm">
                <button type="button" class="usr-modal-close" @click="editProv = null"><i class="bi bi-x-lg"></i></button>
                <template x-if="editProv">
                    <div>
                        <div class="usr-modal-header">
                            <span class="usr-modal-icon" style="background:var(--purple-bg); color:var(--clr-accent);"><i class="bi bi-pencil-square"></i></span>
                            <h2 class="usr-modal-title">Editar <span>proveedor</span></h2>
                        </div>
                        <div class="usr-modal-body">
                            <form method="POST" :action="'/proveedores/' + editProv.id">
                                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                <div class="form-group" style="margin-bottom:14px;">
                                    <label style="color:var(--clr-text); font-size:12px; font-weight:700; display:block; margin-bottom:5px;">Nombre de la empresa</label>
                                    <input type="text" name="nombre_empresa" x-model="editProv.nombre_empresa" required maxlength="150"
                                           style="width:100%; padding:9px 13px; border:1.5px solid rgba(180,138,212,.4); border-radius:10px; font-size:13px; background:#fff; color:var(--clr-text);">
                                </div>
                                <div class="form-group" style="margin-bottom:14px;">
                                    <label style="color:var(--clr-text); font-size:12px; font-weight:700; display:block; margin-bottom:5px;">Persona de contacto</label>
                                    <input type="text" name="contacto" x-model="editProv.contacto" maxlength="150"
                                           style="width:100%; padding:9px 13px; border:1.5px solid rgba(180,138,212,.4); border-radius:10px; font-size:13px; background:#fff; color:var(--clr-text);">
                                </div>
                                <div class="form-group" style="margin-bottom:14px;">
                                    <label style="color:var(--clr-text); font-size:12px; font-weight:700; display:block; margin-bottom:5px;">Teléfono</label>
                                    <input type="text" name="telefono" x-model="editProv.telefono" maxlength="20"
                                           style="width:100%; padding:9px 13px; border:1.5px solid rgba(180,138,212,.4); border-radius:10px; font-size:13px; background:#fff; color:var(--clr-text);">
                                </div>
                                <div class="form-group" style="margin-bottom:14px;">
                                    <label style="color:var(--clr-text); font-size:12px; font-weight:700; display:block; margin-bottom:5px;">Email</label>
                                    <input type="email" name="email" x-model="editProv.email" maxlength="255"
                                           style="width:100%; padding:9px 13px; border:1.5px solid rgba(180,138,212,.4); border-radius:10px; font-size:13px; background:#fff; color:var(--clr-text);">
                                </div>
                                <div class="form-group" style="margin-bottom:14px;">
                                    <label style="color:var(--clr-text); font-size:12px; font-weight:700; display:block; margin-bottom:5px;">Dirección</label>
                                    <input type="text" name="direccion" x-model="editProv.direccion" maxlength="255"
                                           style="width:100%; padding:9px 13px; border:1.5px solid rgba(180,138,212,.4); border-radius:10px; font-size:13px; background:#fff; color:var(--clr-text);">
                                </div>
                                <div class="usr-toggle-row">
                                    <span>Proveedor activo</span>
                                    <label class="usr-switch">
                                        <input type="checkbox" name="activo" value="1" x-model="editProv.activo">
                                        <span class="usr-switch-slider"></span>
                                    </label>
                                </div>
                                <div class="usr-modal-footer">
                                    <button type="button" class="usr-btn-cancel" @click="editProv = null">Cancelar</button>
                                    <button type="submit" class="usr-btn-submit"><i class="bi bi-check-lg"></i> Guardar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </template>
            </div>
        </div>

        <div x-show="deleteProv" x-cloak class="fixed inset-0 z-[1300] flex items-center justify-center p-4"
             style="background: rgba(50,20,70,.45); backdrop-filter: blur(6px);">
            <div @click.outside="deleteProv = null" class="usr-modal-box usr-modal-box--sm">
                <button type="button" class="usr-modal-close" @click="deleteProv = null"><i class="bi bi-x-lg"></i></button>
                <div class="usr-modal-header">
                    <span class="usr-modal-icon" style="background:#fde8e8; color:#b03030;"><i class="bi bi-trash3-fill"></i></span>
                    <h2 class="usr-modal-title" style="color:#b03030;">Eliminar <span style="color:#b03030;">Proveedor</span></h2>
                </div>
                <template x-if="deleteProv">
                    <div class="usr-modal-body">
                        <p class="usr-delete-msg">¿Seguro que deseas eliminar <strong x-text="deleteProv.nombre"></strong>? Esta acción no se puede deshacer.</p>
                        <form method="POST" :action="'/proveedores/' + deleteProv.id">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <div class="usr-modal-footer">
                                <button type="button" class="usr-btn-cancel" @click="deleteProv = null">Cancelar</button>
                                <button type="submit" class="usr-btn-delete"><i class="bi bi-trash3"></i> Eliminar</button>
                            </div>
                        </form>
                    </div>
                </template>
            </div>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\control-productos-capilares\resources\views/proveedores/index.blade.php ENDPATH**/ ?>